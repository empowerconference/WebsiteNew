# Makefile #

This directory contains a sample Makefile to build the LaTeX templates with old-school `make`.
Copy this file to the top-level `LaTeX` directory and run make to build PDF files. 

If your LaTeX file(s) have different names, change the target filename(s) in the initial `all` rule.
If your BibTeX file(s) have different names, change the filename(s) at the end of the `%.bbl` rule.
