# EndNote Output Style #

This directory contains an [EndNote Output Style][ENS] for the Word Template.

Written by Cliff Lampe but open for edits and improvements.

[ENS]: http://endnote.com/downloads/styles "EndNote Styles"


