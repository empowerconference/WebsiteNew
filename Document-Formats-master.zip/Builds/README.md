# Builds #

These are compressed releases of the repository for easy linking to
websites.  They should be built whenever the master branch is updated
or pull requests are accepted.

Check ```last_build_date``` to see how fresh the compressed bundles
are.

